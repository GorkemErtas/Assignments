public class Elevator {
    private ElevatorState currentState;
    private int currentFloor;

    public Elevator() {
        this.currentState = new StationaryState(this);
        this.currentFloor = 0;
    }

    public void changeState(ElevatorState newState) {
        this.currentState = newState;
    }

    public int getCurrentFloor() {
        return currentFloor;
    }

    public void setCurrentFloor(int currentFloor) {
        this.currentFloor = currentFloor;
    }

    public void pressButton(int destinationFloor) {
        currentState.pressButton(destinationFloor);
    }
}
