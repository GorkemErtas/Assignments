public class MovingUpState implements ElevatorState {
    private Elevator elevator;

    public MovingUpState(Elevator elevator) {
        this.elevator = elevator;
    }

    @Override
    public void pressButton(int destinationFloor) {
        int currentFloor = elevator.getCurrentFloor();
        if (destinationFloor > currentFloor) {
            System.out.println("Elevator is moving up to floor " + destinationFloor);
            elevator.setCurrentFloor(destinationFloor);
        }
    }
}
