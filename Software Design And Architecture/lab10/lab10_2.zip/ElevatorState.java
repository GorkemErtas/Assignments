public interface ElevatorState {
    void pressButton(int destinationFloor);
}
