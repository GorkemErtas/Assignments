public class Main {
    public static void main(String[] args) {
        Elevator elevator = new Elevator();
        elevator.pressButton(3);
        elevator.pressButton(5);
        elevator.pressButton(2);
    }
}