public class MovingDownState implements ElevatorState {
    private Elevator elevator;

    public MovingDownState(Elevator elevator) {
        this.elevator = elevator;
    }

    @Override
    public void pressButton(int destinationFloor) {
        int currentFloor = elevator.getCurrentFloor();
        if (destinationFloor < currentFloor) {
            System.out.println("Elevator is moving down to floor " + destinationFloor);
            elevator.setCurrentFloor(destinationFloor);
        }
    }
}
