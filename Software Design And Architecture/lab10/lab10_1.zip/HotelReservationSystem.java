import java.time.LocalDate;
public class HotelReservationSystem {
    public void reserveHotel(String city, LocalDate checkInDate, LocalDate checkOutDate) {
        System.out.println("Hotel reserved in " + city + " from " + checkInDate + " to " + checkOutDate);
    }
}
