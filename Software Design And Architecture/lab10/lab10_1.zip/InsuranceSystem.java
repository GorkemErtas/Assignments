import java.time.LocalDate;
public class InsuranceSystem {
    public void purchaseInsurance(String destinationCity, LocalDate startDate, LocalDate endDate) {
        System.out.println("Insurance purchased for the trip to " + destinationCity + " from " + startDate + " to " + endDate);
    }
}
