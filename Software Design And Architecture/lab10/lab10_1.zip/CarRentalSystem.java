import java.time.LocalDate;
public class CarRentalSystem {
    public void rentCar(String city, LocalDate startDate, int numberOfDays) {
        System.out.println("Car rented in " + city + " from " + startDate + " for " + numberOfDays + " days");
    }
}
