import java.time.LocalDate;
 class FlightBookingSystem {
    public void bookFlight(String departureCity, String destinationCity, LocalDate departureDate) {
        System.out.println("Flight booked from " + departureCity + " to " + destinationCity + " on " + departureDate);
    }
}
