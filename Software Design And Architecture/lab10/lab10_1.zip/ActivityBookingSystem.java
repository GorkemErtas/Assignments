import java.time.LocalDate;
public class ActivityBookingSystem {
    public void bookActivity(String city, String activity, LocalDate date) {
        System.out.println("Activity booked in " + city + " : " + activity + " on " + date);
    }
}
