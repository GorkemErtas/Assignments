import java.time.LocalDate;
public class Main {
    public static void main(String[] args) {
        TravelFacade travelFacade = new TravelFacade();

        LocalDate departureDate = LocalDate.of(2023, 12, 11);
        LocalDate checkInDate = LocalDate.of(2023, 12, 11);
        LocalDate checkOutDate = LocalDate.of(2023, 12, 17);
        LocalDate carStartDate = LocalDate.of(2023, 12, 11);
        int carDays = 6;
        LocalDate activityDate = LocalDate.of(2023, 12, 15);
        LocalDate insuranceStartDate = LocalDate.of(2023, 12, 11);
        LocalDate insuranceEndDate = LocalDate.of(2023, 12, 17);

        travelFacade.planTrip("Izmir", "Istanbul", departureDate, checkInDate, checkOutDate,
                carStartDate, carDays, "Sightseeing Tour", activityDate, insuranceStartDate, insuranceEndDate);
    }
}