public class NotificationService {
    public void notifyUser(String message) {
        System.out.println("Notification : " + message);
    }
}
