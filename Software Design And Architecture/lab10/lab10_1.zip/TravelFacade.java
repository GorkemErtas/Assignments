import java.time.LocalDate;
public class TravelFacade {
    private FlightBookingSystem flightBookingSystem;
    private HotelReservationSystem hotelReservationSystem;
    private CarRentalSystem carRentalSystem;
    private ActivityBookingSystem activityBookingSystem;
    private InsuranceSystem insuranceSystem;
    private NotificationService notificationService;

    public TravelFacade() {
        this.flightBookingSystem = new FlightBookingSystem();
        this.hotelReservationSystem = new HotelReservationSystem();
        this.carRentalSystem = new CarRentalSystem();
        this.activityBookingSystem = new ActivityBookingSystem();
        this.insuranceSystem = new InsuranceSystem();
        this.notificationService = new NotificationService();
    }

    public void planTrip(String departureCity, String destinationCity, LocalDate departureDate,
                         LocalDate checkInDate, LocalDate checkOutDate, LocalDate carStartDate,
                         int carDays, String activity, LocalDate activityDate, LocalDate insuranceStartDate,
                         LocalDate insuranceEndDate) {
        flightBookingSystem.bookFlight(departureCity, destinationCity, departureDate);
        hotelReservationSystem.reserveHotel(destinationCity, checkInDate, checkOutDate);
        carRentalSystem.rentCar(destinationCity, carStartDate, carDays);
        activityBookingSystem.bookActivity(destinationCity, activity, activityDate);
        insuranceSystem.purchaseInsurance(destinationCity, insuranceStartDate, insuranceEndDate);
        notificationService.notifyUser("Your trip is booked successfully!");
    }
}
