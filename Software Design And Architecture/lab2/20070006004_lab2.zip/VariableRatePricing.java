public class VariableRatePricing implements PricingStrategy {
    @Override
    public String printPricingType() {
        return "Variable Rate";
    }

    @Override
    public double calculateDeliveryPrice() {
        return 10;
    }
}
