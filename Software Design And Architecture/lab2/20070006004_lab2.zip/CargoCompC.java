public class CargoCompC extends CargoCompany {

    public CargoCompC() {
        super(new StandardDelivery(), new VariableRatePricing());
    }
}
