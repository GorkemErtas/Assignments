public interface PricingStrategy {
    String printPricingType();

    double calculateDeliveryPrice();
}
