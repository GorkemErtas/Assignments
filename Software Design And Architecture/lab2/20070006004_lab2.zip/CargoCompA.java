public class CargoCompA extends CargoCompany {

    public CargoCompA() {
        super(new StandardDelivery(), new FlatRatePricing());
    }
}
