public interface DeliveryStrategy {
    String printDeliveryType();
    int calculateDeliveryTime();
}
