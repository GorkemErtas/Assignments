public class CargoCompB extends CargoCompany {

    public CargoCompB() {
        super(new ExpressDelivery(), new FlatRatePricing());
    }
}
