public class CargoCompany {
    public DeliveryStrategy deliveryStrategy;
    public PricingStrategy pricingStrategy;

    public CargoCompany(DeliveryStrategy deliveryStrategy, PricingStrategy pricingStrategy) {
        this.deliveryStrategy = deliveryStrategy;
        this.pricingStrategy = pricingStrategy;
    }

    public void setDeliveryStrategy(DeliveryStrategy deliveryStrategy) {
        this.deliveryStrategy = deliveryStrategy;
    }

    public void setPricingStrategy(PricingStrategy pricingStrategy) {
        this.pricingStrategy = pricingStrategy;
    }

    @Override
    public String toString() {
        return "CargoCompany{" +
                "Delivery Type=" + deliveryStrategy.printDeliveryType() +
                ", Pricing Type=" + pricingStrategy.printPricingType() +
                ", Delivery Time=" + deliveryStrategy.calculateDeliveryTime() +
                ", Delivery Price=" + pricingStrategy.calculateDeliveryPrice() +
                '}';
    }
}
