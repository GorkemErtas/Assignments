public class Main {
    public static void main(String[] args) {
        CargoCompany compA = new CargoCompA();
        CargoCompany compB = new CargoCompB();
        CargoCompany compC = new CargoCompC();
        System.out.println("Company A " + compA);
        System.out.println("Company B " + compB);
        System.out.println("Company C " + compC);
    }
}