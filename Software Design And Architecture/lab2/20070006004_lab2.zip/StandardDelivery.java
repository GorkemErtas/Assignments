public class StandardDelivery implements DeliveryStrategy {
    @Override
    public String printDeliveryType() {
        return "Standard";
    }

    @Override
    public int calculateDeliveryTime() {
        return 3;
    }
}
