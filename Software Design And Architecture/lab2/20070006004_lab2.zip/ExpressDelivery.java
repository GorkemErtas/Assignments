public class ExpressDelivery implements DeliveryStrategy {
    @Override
    public String printDeliveryType() {
        return "Express";
    }

    @Override
    public int calculateDeliveryTime() {
        return 1;
    }
}
