public class FlatRatePricing implements PricingStrategy {

    @Override
    public String printPricingType() {
        return "Flat Rate";
    }

    @Override
    public double calculateDeliveryPrice() {
        return 5;
    }
}
