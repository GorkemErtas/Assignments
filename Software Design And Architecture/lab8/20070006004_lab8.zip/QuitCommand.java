public class QuitCommand implements Command {
    private GameCharacter character;

    public QuitCommand(GameCharacter character) {
        this.character = character;
    }

    @Override
    public void execute() {
        character.quit();
    }
}
