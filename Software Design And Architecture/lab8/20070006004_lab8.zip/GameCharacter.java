public class GameCharacter {
    public void moveUp(){
        System.out.println("Character moves up.");
    }
    public void moveDown(){
        System.out.println("Character moves down.");
    }
    public void moveRight(){
        System.out.println("Character moves right.");
    }
    public void moveLeft(){
        System.out.println("Character moves left.");
    }
    public void jump(){
        System.out.println("Character jumps.");
    }
    public void attack(){
        System.out.println("Character attacks.");
    }
    public void quit(){
        System.out.println("Quitting the game.");
    }
}
