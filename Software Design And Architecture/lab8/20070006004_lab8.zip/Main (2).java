import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        GameCharacter character = new GameCharacter();
        GameController controller = new GameController();
        Command moveUp = new MoveUpCommand(character);
        Command moveDown = new MoveDownCommand(character);
        Command moveRight = new MoveRightCommand(character);
        Command moveLeft = new MoveLeftCommand(character);
        Command jump = new JumpCommand(character);
        Command attack = new AttackCommand(character);
        Command quit = new QuitCommand(character);
        String action;
        do {
            System.out.println("Select an action:\n");
            System.out.println("w - Move Up\n a - Move Left\n s - Move Down\n d - Move Right\n j - Jump\n k - Attack\n q - Quit\n");
            Scanner scanner = new Scanner(System.in);
           action = scanner.nextLine();
            switch (action) {
                case "w":
                    character.moveUp();
                    break;
                case "a":
                    character.moveLeft();
                    break;
                case "s":
                    character.moveDown();
                    break;
                case "d":
                    character.moveRight();
                    break;
                case "j":
                    character.jump();
                    break;
                case "k":
                    character.attack();
                    break;
                case "q":
                    character.quit();
                    break;
                default:
                    System.out.println("Invalid command. Try again.");
            }
        }while(!action.equals("q"));
    }
}