import java.util.ArrayList;
import java.util.Scanner;
public class MusicPlayer {
    private static MusicPlayer instance;
    private boolean isPlaying;
    private ArrayList<String> playlist;
    private MusicPlayer(){
        isPlaying = false;
        playlist = new ArrayList<>();
    }

    public static MusicPlayer getInstance(){
        if(instance == null){
            instance = new MusicPlayer();
        }
        return instance;
    }
    public void playMP3(){
        if(!playlist.isEmpty()){
            System.out.println("Choose a song to play from the playlist:");
            showPlaylist();
            int i = new Scanner(System.in).nextInt();
            String song = playlist.get(i - 1);
            System.out.println("Playing MP3: " + song);
            isPlaying = true;
        }else {
            System.out.println("Playlist is empty.");
        }
    }
    public void playFLAC(){
        if(!playlist.isEmpty()){
            System.out.println("Choose a song to play from the playlist:");
            showPlaylist();
            int i = new Scanner(System.in).nextInt();
            String song = playlist.get(i - 1);
            System.out.println("Playing FLAC: " + song);
            isPlaying = true;
        }else {
            System.out.println("Playlist is empty.");
        }
    }
    public void playAAC(){
        if(!playlist.isEmpty()){
            System.out.println("Choose a song to play from the playlist:");
            showPlaylist();
            int i = new Scanner(System.in).nextInt();
            String song = playlist.get(i - 1);
            System.out.println("Playing AAC: " + song);
            isPlaying = true;
        }else {
            System.out.println("Playlist is empty.");
        }
    }
    public void addToPlaylist(String song){
        playlist.add(song);
        System.out.println("Adding to playlist: " + song);
    }
    public void removeTFromPlaylist(String song){
        if(playlist.contains(song)){
            playlist.remove(song);
            System.out.println("Removing from playlist: " + song);
        } else{
            System.out.println("Song not found in playlist.");
        }
    }
    public void showPlaylist(){
        System.out.println("Playlist: ");
        for(int i = 0; i < playlist.size(); i++){
            System.out.println(i + 1 + ". " + playlist.get(i));
        }
    }
    public void authenticateUser(String user){
        System.out.println("Authenticating user: " + user);
    }
    public void logEvent(String event){
        System.out.println("Logging event: " + event);
    }
    public void exit(){
        System.out.println("Exiting Music PLayer");
        System.exit(0);
    }
}
