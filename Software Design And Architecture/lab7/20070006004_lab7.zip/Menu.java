import java.util.Scanner;
public class Menu {
    private MusicPlayer musicPlayer;
    private Scanner scanner;
    public Menu(MusicPlayer musicPlayer){
        this.musicPlayer = musicPlayer;
        this.scanner = new Scanner(System.in);
    }
    public void displayMenu(){
        while(true){
            System.out.println("---Music Player Menu---");
            System.out.println("1. Play MP3");
            System.out.println("2. Play FLAC");
            System.out.println("3. PLay AAC");
            System.out.println("4. Add to Playlist");
            System.out.println("5. Remove from Playlist");
            System.out.println("6. Show Playlist");
            System.out.println("7. Authenticate User");
            System.out.println("8. Log Event");
            System.out.println("0. Exit");

            int userInput = scanner.nextInt();

            switch(userInput){
                case 1:
                    musicPlayer.playMP3();
                    break;
                case 2:
                    musicPlayer.playFLAC();
                    break;
                case 3:
                    musicPlayer.playAAC();
                    break;
                case 4:
                    System.out.println("Enter song name: ");
                    String songToAdd = scanner.next();
                    musicPlayer.addToPlaylist((songToAdd));
                    break;
                case 5:
                    System.out.println("Enter song name: ");
                    String songToRemove = scanner.next();
                    musicPlayer.removeTFromPlaylist(songToRemove);
                    break;
                case 6:
                    musicPlayer.showPlaylist();
                    break;
                case 7:
                    System.out.println("Enter username: ");
                    String username = scanner.next();
                    musicPlayer.authenticateUser(username);
                    break;
                case 8:
                    System.out.println("Enter event: ");
                    String event = scanner.next();
                    musicPlayer.logEvent(event);
                    break;
                case 0:
                    musicPlayer.exit();
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
