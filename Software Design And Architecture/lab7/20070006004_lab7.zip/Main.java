import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        MusicPlayer musicPlayer = MusicPlayer.getInstance();
        Menu menu = new Menu(musicPlayer);
        menu.displayMenu();
    }
}