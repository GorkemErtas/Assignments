public class Main {
    public static void main(String[] args) {
        Cube c1 = new Cube("abc", "3D", 5);
        Circle ci1 = new Circle("dfe", "2D", 7);
        Rectangle r1 = new Rectangle("try", "2D", 4, 9);
        Sphere s1 = new Sphere("jgh", "3D", 6);
        System.out.println(c1.toString() + "\n");
        System.out.println(ci1.toString() + "\n");
        System.out.println(r1.toString() + "\n");
        System.out.println(s1.toString());
    }
}