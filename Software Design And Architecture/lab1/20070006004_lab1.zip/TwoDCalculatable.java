public interface TwoDCalculatable {
    double calculateArea();
    double calculatePerimeter();
}
