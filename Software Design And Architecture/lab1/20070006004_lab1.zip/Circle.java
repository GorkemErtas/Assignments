public class Circle extends TwoDimShapes implements TwoDCalculatable {
    double radius;

    public Circle(String nameOfShape, String shapeTypes, double radius) {
        super(nameOfShape, shapeTypes);
        this.radius = radius;
    }

    @Override
    public double calculateArea() {
        return Math.PI * radius * radius;
    }

    @Override
    public double calculatePerimeter() {
        return 2 * Math.PI * radius;
    }

    @Override
    public String toString() {
        return "Circle{" + "radius=" + radius + ", shapeTypes=" + shapeTypes +
                '\'' + ", nameOfShape=" + nameOfShape +
                '\'' + ", Area=" + calculateArea() + ", Perimeter=" + calculatePerimeter() + '}';
    }
}
