public class Sphere extends ThreeDimShapes implements ThreeDCalculatable, TwoDCalculatable {
    double radius;
    public Sphere(String nameOfShape, String shapeTypes, double radius) {
        super(nameOfShape, shapeTypes);
        this.radius = radius;
    }

    @Override
    public double calculateVolume() {
        return (4.0 / 3.0) * Math.PI * radius * radius * radius;
    }

    @Override
    public double calculateArea() {
        return 4 * Math.PI * radius * radius;
    }

    @Override
    public double calculatePerimeter() {
        return 2 * Math.PI * radius * radius;
    }

    @Override
    public String toString() {
        return "Sphere{" +
                "radius=" + radius +
                ", shapeTypes='" + shapeTypes + '\'' +
                ", nameOfShape='" + nameOfShape + '\'' +
                ", Area=" + calculateArea() + ", Volume=" + calculateVolume() + ", Perimeter=" + calculatePerimeter() +
                '}';
    }
}
