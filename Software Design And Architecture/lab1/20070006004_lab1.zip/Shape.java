public abstract class Shape {
    String nameOfShape;
    public Shape(String nameOfShape) {
        this.nameOfShape = nameOfShape;
    }
}
