public class Cube extends ThreeDimShapes implements ThreeDCalculatable, TwoDCalculatable {
    double edge;
    public Cube(String nameOfShape, String shapeTypes, double edge) {
        super(nameOfShape, shapeTypes);
        this.edge = edge;
    }

    @Override
    public double calculateVolume() {
        return edge * edge * edge;
    }

    @Override
    public double calculateArea() {
        return 6 * edge * edge;
    }

    @Override
    public double calculatePerimeter() {
        return 12 * edge;
    }

    @Override
    public String toString() {
        return "Cube{" +
                "edge=" + edge +
                ", shapeTypes='" + shapeTypes + '\'' +
                ", nameOfShape='" + nameOfShape + '\'' +
                ", Area=" + calculateArea() + ", Volume=" + calculateVolume() + ", Perimeter=" + calculatePerimeter() +
                '}';
    }
}
