public class ThreeDimShapes extends Shape {
    String shapeTypes;
    public ThreeDimShapes(String nameOfShape, String shapeTypes) {
        super(nameOfShape);
        this.shapeTypes = shapeTypes;
    }
}
