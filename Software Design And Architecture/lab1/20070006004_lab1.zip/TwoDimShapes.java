public class TwoDimShapes extends Shape {
    String shapeTypes;
    public TwoDimShapes(String nameOfShape, String shapeTypes) {
        super(nameOfShape);
        this.shapeTypes = shapeTypes;
    }
}
