public interface ThreeDCalculatable {
    double calculateVolume();
}
