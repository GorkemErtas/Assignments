public class Rectangle extends TwoDimShapes implements TwoDCalculatable {
    double height;
    double width;
    public Rectangle(String nameOfShape, String shapeTypes, double height, double width) {
        super(nameOfShape, shapeTypes);
        this.height = height;
        this.width = width;
    }

    @Override
    public double calculateArea() {
        return height * width;
    }

    @Override
    public double calculatePerimeter() {
        return 2 * (height + width);
    }

    @Override
    public String toString() {
        return "Rectangle{" +
                "height=" + height +
                ", width=" + width +
                ", shapeTypes=" + shapeTypes + '\'' +
                ", nameOfShape=" + nameOfShape + '\'' +
                ", Area=" + calculateArea() + ", Perimeter=" + calculatePerimeter() +
                '}';
    }
}
