import java.util.ArrayList;

public class TaskController {
    private TaskModel model;
    private TaskView view;
    public TaskController(TaskModel model, TaskView view) {
        this.model = model;
        this.view = view;
    }
    public void addTask(String description) {
        model.addTask(description);
    }
    public void viewTasks() {
        ArrayList<Task> tasks = model.getTasks();
        view.displayTasks(tasks);
    }
    public void markTaskAsCompleted(int index) {
        model.markTaskAsCompleted(index - 1);
    }
}
