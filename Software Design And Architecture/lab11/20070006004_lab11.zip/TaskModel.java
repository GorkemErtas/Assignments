import java.util.ArrayList;

public class TaskModel {
    private ArrayList<Task> tasks = new ArrayList<>();
    public void addTask(String description) {
        Task task = new Task(description);
        tasks.add(task);
    }
    public ArrayList<Task> getTasks() {
        return tasks;
    }
    public void markTaskAsCompleted(int index) {
        if(index >= 0 && index < tasks.size()){
            tasks.get(index).taskCompleted();
        }
    }
}
