import java.util.Scanner;

public class ToDoListApp {
    public static void main(String[] args) {
        TaskModel model = new TaskModel();
        TaskView view = new TaskView();
        TaskController controller = new TaskController(model, view);
        Scanner scanner = new Scanner(System.in);

        int a;
        do {
            System.out.println("Options:");
            System.out.println("1. Add Task");
            System.out.println("2. View Tasks");
            System.out.println("3. Mark Task as Completed");
            System.out.println("4. Exit");
            System.out.println("Enter your choice: ");
            a = scanner.nextInt();
            scanner.nextLine();
            switch(a) {
                case 1:
                    System.out.println("Enter task description: ");
                    String taskDescription = scanner.nextLine();
                    controller.addTask(taskDescription);
                    break;
                case 2:
                    controller.viewTasks();
                    break;
                case 3:
                    System.out.println("Enter task index to mark as completed: ");
                    int taskIndex = scanner.nextInt();
                    controller.markTaskAsCompleted(taskIndex);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        } while(a != 4);
        scanner.close();
    }
}
