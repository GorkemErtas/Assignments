import java.util.ArrayList;

public class TaskView {
    public void displayTasks(ArrayList<Task> tasks) {
        for(int i = 0; i < tasks.size(); i++){
            Task task = tasks.get(i);
            String status = task.isCompleted() ? "[Done]" : "[Waiting]";
            System.out.println((i + 1) + ". " + status + task.getDescription());
        }
    }
}
