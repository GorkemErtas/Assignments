public class ToyotaSedan extends Car {
    public ToyotaSedan() {
        modelName = "B-Class";
        weight = 1500;
        acceleration = 6.7;
        topSpeed = 230;
        price = 26500;
    }

    @Override
    String calculateDeliveryTime() {
        return "5 days";
    }

    @Override
    String calculateProductionTime() {
        return "14 days";
    }

    @Override
    String displayOrigin() {
        return "Japan";
    }

    void display() {
        System.out.println("Model Name='" + modelName + "\n" +
                ", Weight=" + weight + "kg" + "\n" +
                ", Acceleration 0-100 km=" + acceleration + "sec" + "\n" +
                ", Top Speed=" + topSpeed + "km/h" + "\n" +
                ", Price=" + price + "euro" + "\n" +
                ", Origin Country=" + displayOrigin() + "\n" +
                ", Production Time=" + calculateProductionTime() + "\n" +
                ", Delivery Time=" + calculateDeliveryTime());
    }
}
