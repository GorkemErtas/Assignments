public interface CarFactory {
    Car createCar(String item);
}
