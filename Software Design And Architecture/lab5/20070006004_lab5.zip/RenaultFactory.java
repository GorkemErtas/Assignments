public class RenaultFactory implements CarFactory {
    @Override
    public Car createCar(String item) {
        if (item.equals("Sedan")) {
            return new RenaultSedan();
        } else if (item.equals("Hatchback")) {
            return new RenaultHatchback();
        } else if (item.equals("SUV")) {
            return new RenaultSUV();
        }
        else return null;
    }
}
