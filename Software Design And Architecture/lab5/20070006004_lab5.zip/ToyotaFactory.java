public class ToyotaFactory implements CarFactory {
    @Override
    public Car createCar(String item) {
        if (item.equals("Sedan")) {
            return new ToyotaSedan();
        } else if (item.equals("Hatchback")) {
            return new ToyotaHatchback();
        } else if (item.equals("SUV")) {
            return new ToyotaSUV();
        }
        else return null;
    }
}
