public class RenaultSUV extends Car {
    public RenaultSUV() {
        modelName = "A-Class";
        weight = 1230;
        acceleration = 8.0;
        topSpeed = 220;
        price = 24000;
    }

    @Override
    String calculateDeliveryTime() {
        return "7 days";
    }

    @Override
    String calculateProductionTime() {
        return "13 days";
    }

    @Override
    String displayOrigin() {
        return "France";
    }

    void display(){
        System.out.println("Model Name=" + modelName + "\n" +
                ", Weight=" + weight + "kg" + "\n" +
                ", Acceleration 0-100 km=" + acceleration + "sec" + "\n" +
                ", Top Speed=" + topSpeed + "km/h" + "\n" +
                ", Price=" + price + "euro" + "\n" +
                ", Origin Country=" + displayOrigin() + "\n" +
                ", Production Time=" + calculateProductionTime() + "\n" +
                ", Delivery Time=" + calculateDeliveryTime());
    }
}
