public class MercedesFactory implements CarFactory {
    @Override
    public Car createCar(String item) {
        if (item.equals("Sedan")) {
            return new MercedesSedan();
        } else if (item.equals("Hatchback")) {
            return new MercedesHatchback();
        } else if (item.equals("SUV")) {
            return new MercedesSUV();
        }
        else return null;
    }
}
