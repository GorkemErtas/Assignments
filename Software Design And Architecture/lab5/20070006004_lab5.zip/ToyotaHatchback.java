public class ToyotaHatchback extends Car {
    public ToyotaHatchback() {
        modelName = "C-Class";
        weight = 1570;
        acceleration = 6.9;
        topSpeed = 206;
        price = 25400;
    }

    @Override
    String calculateDeliveryTime() {
        return "8 days";
    }

    @Override
    String calculateProductionTime() {
        return "17 days";
    }

    @Override
    String displayOrigin() {
        return "Japan";
    }

    void display() {
        System.out.println("Model Name='" + modelName + "\n" +
                ", Weight=" + weight + "kg" + "\n" +
                ", Acceleration 0-100 km=" + acceleration + "sec" + "\n" +
                ", Top Speed=" + topSpeed + "km/h" + "\n" +
                ", Price=" + price + "euro" + "\n" +
                ", Origin Country=" + displayOrigin() + "\n" +
                ", Production Time=" + calculateProductionTime() + "\n" +
                ", Delivery Time=" + calculateDeliveryTime());
    }
}
