public class ToyotaSUV extends Car {
    public ToyotaSUV() {
        modelName = "A-Class";
        weight = 1380;
        acceleration = 7.8;
        topSpeed = 290;
        price = 30000;
    }

    @Override
    String calculateDeliveryTime() {
        return "4-5 days";
    }

    @Override
    String calculateProductionTime() {
        return "10 days";
    }

    @Override
    String displayOrigin() {
        return "Japan";
    }

    @Override
    void display() {
        System.out.println("Model Name='" + modelName + "\n" +
                ", Weight=" + weight + "kg" + "\n" +
                ", Acceleration 0-100 km=" + acceleration + "sec" + "\n" +
                ", Top Speed=" + topSpeed + "km/h" + "\n" +
                ", Price=" + price + "euro" + "\n" +
                ", Origin Country=" + displayOrigin() + "\n" +
                ", Production Time=" + calculateProductionTime() + "\n" +
                ", Delivery Time=" + calculateDeliveryTime());
    }
}
