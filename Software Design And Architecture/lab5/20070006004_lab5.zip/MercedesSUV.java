public class MercedesSUV extends Car {
    public MercedesSUV() {
        modelName = "A-Class";
        weight = 1190;
        acceleration = 5.2;
        topSpeed = 252;
        price = 29700;
    }

    @Override
    String calculateDeliveryTime() {
        return "7 days";
    }

    @Override
    String calculateProductionTime() {
        return "9 days";
    }

    @Override
    String displayOrigin() {
        return "Germany";
    }

    @Override
    void display() {
        System.out.println("Model Name='" + modelName + "\n" +
                ", Weight=" + weight + "kg" + "\n" +
                ", Acceleration 0-100 km=" + acceleration + "sec" + "\n" +
                ", Top Speed=" + topSpeed + "km/h" + "\n" +
                ", Price=" + price + "euro" + "\n" +
                ", Origin Country=" + displayOrigin() + "\n" +
                ", Production Time=" + calculateProductionTime() + "\n" +
                ", Delivery Time=" + calculateDeliveryTime());
    }


}
