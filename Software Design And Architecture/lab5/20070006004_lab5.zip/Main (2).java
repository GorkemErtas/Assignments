import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        CarFactory cf = null;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter brand choice.");
        String brand = scanner.nextLine();
        if(brand.equals("Mercedes")){
            cf = new MercedesFactory();
        }else if(brand.equals("Renault")){
            cf = new RenaultFactory();
        }else if(brand.equals("Toyota")){
            cf = new ToyotaFactory();
        }
        System.out.println("Enter a body type.");
        String model = scanner.nextLine();
        if(model.equals("Sedan")){
            cf.createCar("Sedan").display();
        }else if(model.equals("Hatchback")){
            cf.createCar("Hatchback").display();
        }else if(model.equals("SUV")){
            cf.createCar("SUV").display();
        }
    }
}