public class RenaultSedan extends Car {
    public RenaultSedan() {
        modelName = "B-Class";
        weight = 1200;
        acceleration = 8.9;
        topSpeed = 241;
        price = 28000;
    }

    @Override
    String calculateDeliveryTime() {
        return "6 days";
    }

    @Override
    String calculateProductionTime() {
        return "11 days";
    }

    @Override
    String displayOrigin() {
        return "France";
    }

    @Override
    void display() {
        System.out.println("Model Name='" + modelName + "\n" +
                ", Weight=" + weight + "kg" + "\n" +
                ", Acceleration 0-100 km=" + acceleration + "sec" + "\n" +
                ", Top Speed=" + topSpeed + "km/h" + "\n" +
                ", Price=" + price + "euro" + "\n" +
                ", Origin Country=" + displayOrigin() + "\n" +
                ", Production Time=" + calculateProductionTime() + "\n" +
                ", Delivery Time=" + calculateDeliveryTime());
    }


}
