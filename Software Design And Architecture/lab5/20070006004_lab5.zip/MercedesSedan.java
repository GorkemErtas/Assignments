public class MercedesSedan extends Car {
    public MercedesSedan() {
        modelName = "B-Class";
        weight = 1300;
        acceleration = 7.3;
        topSpeed = 230;
        price = 31000;
    }

    @Override
    String calculateDeliveryTime() {
        return "6 days";
    }

    @Override
    String calculateProductionTime() {
        return "15 days";
    }

    @Override
    String displayOrigin() {
        return "Germany";
    }

    @Override
    void display() {
        System.out.println("Model Name='" + modelName + "\n" +
                ", Weight=" + weight + "kg" + "\n" +
                ", Acceleration 0-100 km=" + acceleration + "sec" + "\n" +
                ", Top Speed=" + topSpeed + "km/h" + "\n" +
                ", Price=" + price + "euro" + "\n" +
                ", Origin Country=" + displayOrigin() + "\n" +
                ", Production Time=" + calculateProductionTime() + "\n" +
                ", Delivery Time=" + calculateDeliveryTime());
    }


}
