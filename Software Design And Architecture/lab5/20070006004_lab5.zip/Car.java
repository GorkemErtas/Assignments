public abstract class Car {
    String modelName;
    double weight;
    double acceleration;
    double topSpeed;
    double price;

    public Car() {
        this.modelName = modelName;
        this.weight = weight;
        this.acceleration = acceleration;
        this.topSpeed = topSpeed;
        this.price = price;
    }
    abstract String calculateDeliveryTime();
    abstract String calculateProductionTime();
    abstract String displayOrigin();
    abstract void display();

}
