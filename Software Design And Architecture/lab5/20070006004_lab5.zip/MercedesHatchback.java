public class MercedesHatchback extends Car {
    public MercedesHatchback() {
        modelName = "C-Class";
        weight = 1600;
        acceleration = 8.2;
        topSpeed = 255;
        price = 31500;
    }

    @Override
    String calculateDeliveryTime() {
        return "5 days";
    }

    @Override
    String calculateProductionTime() {
        return "12 days";
    }

    @Override
    String displayOrigin() {
        return "Germany";
    }

    @Override
    void display() {
        System.out.println("Model Name='" + modelName + "\n" +
                ", Weight=" + weight + "kg" + "\n" +
                ", Acceleration 0-100 km=" + acceleration + "sec" + "\n" +
                ", Top Speed=" + topSpeed + "km/h" + "\n" +
                ", Price=" + price + "euro" + "\n" +
                ", Origin Country=" + displayOrigin() + "\n" +
                ", Production Time=" + calculateProductionTime() + "\n" +
                ", Delivery Time=" + calculateDeliveryTime());
    }


}
