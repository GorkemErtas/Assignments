public class Main {
    public static void main(String[] args) {
        Channel v = new Channel("Veritasium");
        Channel mP = new Channel("Minute Physics");

        Observer s1 = new NormalSubscriber("Elena");
        Observer s2 = new NormalSubscriber("Derek");
        Observer s3 = new PremiumSubscriber("Gale");
        Observer s4 = new PremiumSubscriber("Lane");

        v.register(s1);
        v.register(s2);
        mP.register(s3);
        mP.register(s4);

        v.notifyObservers();
        mP.notifyObservers();
    }
}