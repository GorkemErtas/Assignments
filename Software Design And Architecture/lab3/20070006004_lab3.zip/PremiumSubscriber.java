public class PremiumSubscriber implements Observer {
    private String name;

    public PremiumSubscriber(String name) {
        this.name = name;
    }

    @Override
    public void update(String message) {
        System.out.println("Wake up " + name + "!! " + message + " uploaded new video without ads for premium subscribers.");
    }
}
