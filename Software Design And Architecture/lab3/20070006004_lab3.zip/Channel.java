import java.util.ArrayList;
import java.util.List;
public class Channel implements Subject {
    public String name;

    private List <Observer> Subscribers = new ArrayList<>();

    public Channel(String name) {
        this.name = name;
    }

    @Override
    public void register(Observer observer) {
        Subscribers.add(observer);

    }

    @Override
    public void remove(Observer observer) {
        Subscribers.remove(observer);
    }

    @Override
    public void notifyObservers() {
        for(Observer observer: Subscribers){
            observer.update(name);
        }
    }
}
