public class NormalSubscriber implements Observer {
    private String name;

    public NormalSubscriber(String name) {
        this.name = name;
    }

    @Override
    public void update(String message) {
        System.out.println("Wake up "+ name + "!! " + message + " uploaded new video.");
    }
}
