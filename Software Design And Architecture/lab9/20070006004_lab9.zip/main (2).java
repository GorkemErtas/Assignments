public class main {
    public static void main(String[] args) {
        ExcelFileAdapter excelAdapter = new ExcelFileAdapter(new ExcelFileAdapter());
        String excelContent = excelAdapter.readFile("path/to/excel/file.xlsx");
        System.out.println(excelContent);
    }
}
