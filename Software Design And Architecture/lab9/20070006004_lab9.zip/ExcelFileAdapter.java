public class ExcelFileAdapter implements FileReaderr {
    private ExcelFileAdapter excelReader;

    public ExcelFileAdapter(ExcelFileAdapter excelReader) {
        this.excelReader = excelReader;
    }

    @Override
    public String readFile(String filePath) {
        return excelReader.readExcelFile(filePath);
    }
}
