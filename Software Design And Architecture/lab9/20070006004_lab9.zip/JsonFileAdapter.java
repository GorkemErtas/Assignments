public class JsonFileAdapter implements FileReaderr{
    private JsonFileReader jsonReader;
    public JsonFileAdapter(JsonFileReader jsonReader) {
        this.jsonReader = jsonReader;
    }

    @Override
    public String readFile(String filePath) {
        return jsonReader.readJsonFile(filePath);
    }
}
