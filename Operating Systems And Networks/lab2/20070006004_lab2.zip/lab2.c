#include<stdio.h>
#include<pthread.h>
int num = 0;
FILE *fp;
pthread_mutex_t lock;
void add()
{
 while(1)
 {
 pthread_mutex_lock(&lock);
 fprintf(fp,"Thread 1 - %d\n",num);
 num++;
 sleep(1);
 pthread_mutex_unlock(&lock);
 }
}
void inc()
{
 while(1)
 {
 pthread_mutex_lock(&lock);
 fprintf(fp,"Thread 2 - %d\n",num);
 num++;
 sleep(1);
 pthread_mutex_unlock(&lock);
 }
}
void main()
{
	fp = fopen("gorkem.txt", "w");
 pthread_t t1,t2;
 pthread_mutex_init(&lock, NULL);
 pthread_create(&t1,NULL,add,NULL);
 pthread_create(&t2,NULL,inc,NULL);
 pthread_join(t1,NULL);
 pthread_join(t2,NULL);
}
