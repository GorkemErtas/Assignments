#include <windows.h>
#include <stdio.h>
#include <tchar.h>
int main()
{
FILE *fp;
fp = fopen("Test.txt", "w");
fprintf(fp, "%s\n", "G�rkem Ertas   20070006004");
fclose(fp);
system("pause");
return 0;
}
